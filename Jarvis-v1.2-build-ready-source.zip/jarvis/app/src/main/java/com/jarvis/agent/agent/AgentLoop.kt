package com.jarvis.agent.agent

import com.jarvis.agent.ai.ChatMessage
import com.jarvis.agent.ai.LlmProvider
import com.jarvis.agent.ai.Role
import com.jarvis.agent.control.DeviceTools
import kotlinx.coroutines.CancellationException

/**
 * حلقة الوكيل: تفكير ← تنفيذ أداة ← ملاحظة ← تكرار، حتى ينهي النموذج المهمة.
 * تبثّ كل خطوة عبر callback لعرضها في الواجهة.
 */
class AgentLoop(
    private val llm: LlmProvider,
    private val tools: DeviceTools,
    private val maxSteps: Int = 25
) {
    private val history = mutableListOf<ChatMessage>()

    /** أحداث تُبثّ للواجهة أثناء العمل. */
    sealed interface Event {
        data class Thinking(val text: String) : Event
        data class Action(val tool: String, val args: String) : Event
        data class Observation(val result: String) : Event
        data class Done(val summary: String) : Event
        data class Failed(val error: String) : Event
    }

    /** يبدأ مهمة جديدة من أمر المستخدم. */
    suspend fun run(userGoal: String, emit: suspend (Event) -> Unit) {
        history.add(ChatMessage(Role.USER, userGoal))
        val toolSpecs = tools.specs()

        try {
            repeat(maxSteps) {
                val result = llm.chat(SYSTEM_PROMPT, history, toolSpecs)

                // نص تفكير/رد
                result.assistantText?.takeIf { it.isNotBlank() }?.let {
                    emit(Event.Thinking(it))
                }

                // لا استدعاءات أدوات ⇒ انتهى النموذج بالكلام
                if (result.toolCalls.isEmpty()) {
                    val final = result.assistantText ?: "اكتملت المهمة."
                    history.add(ChatMessage(Role.ASSISTANT, final))
                    emit(Event.Done(final))
                    return
                }

                // سجّل رسالة المساعد مع استدعاءاته
                history.add(
                    ChatMessage(
                        Role.ASSISTANT,
                        result.assistantText.orEmpty(),
                        toolCalls = result.toolCalls
                    )
                )

                // نفّذ كل أداة بالتسلسل
                for (call in result.toolCalls) {
                    emit(Event.Action(call.name, call.argumentsJson))
                    val outcome = tools.execute(call.name, call.argumentsJson)
                    emit(Event.Observation(outcome.result))

                    // ناتج الأداة يعود للنموذج. لـ Gemini نستخدم الاسم كمعرّف.
                    history.add(
                        ChatMessage(
                            Role.TOOL,
                            outcome.result,
                            toolCallId = if (call.id.startsWith("gemini_")) call.name else call.id
                        )
                    )

                    if (outcome.isFinish) {
                        emit(Event.Done(outcome.result))
                        return
                    }
                }
            }
            emit(Event.Failed("توقّفت بعد $maxSteps خطوة دون إنهاء. جرّب تبسيط الطلب."))
        } catch (e: CancellationException) {
            throw e // Stopping a task must never be reported as a provider failure.
        } catch (e: Exception) {
            emit(Event.Failed(e.message ?: "خطأ غير متوقع"))
        }
    }

    fun reset() = history.clear()

    companion object {
        val SYSTEM_PROMPT = """
أنت «جارفيس»، وكيل ذكاء اصطناعي يتحكم في هاتف أندرويد نيابة عن المستخدم.

مبادئك:
1. فكّر خطوة بخطوة. قبل أي تفاعل، استخدم read_screen لترى ما على الشاشة فعلاً — لا تخمّن.
2. استخدم فهارس العناصر [index] من read_screen للنقر والكتابة؛ هي أدق من الإحداثيات.
3. بعد كل إجراء مهم (فتح تطبيق، تمرير، نقر ينقل لشاشة جديدة) اقرأ الشاشة من جديد للتحقق.
4. لفتح تطبيق استخدم open_app بالاسم مباشرة (مثل «واتساب»)؛ إن فشل استخدم list_apps.
5. run_shell يعمل فقط على الهواتف المروّتة؛ إن أخبرك أنه غير متاح فأكمل بالنقر والكتابة عبر الواجهة.
6. تكلّم مع المستخدم بالعربية. عند انتهاء المهمة استدعِ finish مع خلاصة واضحة.
7. إن كان الطلب غامضاً أو خطيراً (حذف، دفع، إرسال)، نفّذ بحذر وأبلغ المستخدم بما فعلت.

كن عملياً ومباشراً. هدفك إنجاز ما يطلبه المستخدم على الهاتف بأقل عدد خطوات.
""".trim()
    }
}
