package com.jarvis.agent.control

import com.jarvis.agent.ai.ParamSpec
import com.jarvis.agent.ai.ToolSpec
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*

/**
 * سجلّ الأدوات: يعرّف ما يستطيع الوكيل فعله، وينفّذه فعلياً على الجهاز.
 * يجمع بين Accessibility (قراءة الشاشة + إيماءات) والروت (تحكم مطلق).
 */
class DeviceTools(private val context: android.content.Context) {

    private val apps = AppLauncher(context)

    private val json = Json { ignoreUnknownKeys = true }

    /** قائمة الأدوات التي تُعرض للنموذج. */
    fun specs(): List<ToolSpec> = listOf(
        ToolSpec(
            name = "read_screen",
            description = "اقرأ محتوى الشاشة الحالية: التطبيق المفتوح وكل العناصر المرئية (أزرار، نصوص، حقول) مع فهارسها ومواضعها. استخدمها دائماً قبل أي تفاعل لتعرف ما أمامك.",
            parameters = emptyMap()
        ),
        ToolSpec(
            name = "tap",
            description = "انقر على عنصر بفهرسه (المفضّل) أو على إحداثيات محددة.",
            parameters = mapOf(
                "index" to ParamSpec("integer", "فهرس العنصر من read_screen"),
                "x" to ParamSpec("integer", "إحداثي أفقي (بديل عن index)"),
                "y" to ParamSpec("integer", "إحداثي رأسي (بديل عن index)")
            )
        ),
        ToolSpec(
            name = "type_text",
            description = "اكتب نصاً في حقل الكتابة. حدّد index للحقل إن عُرف، وإلا يُكتب في الحقل المُركّز.",
            parameters = mapOf(
                "text" to ParamSpec("string", "النص المراد كتابته"),
                "index" to ParamSpec("integer", "فهرس حقل الكتابة (اختياري)")
            ),
            required = listOf("text")
        ),
        ToolSpec(
            name = "swipe",
            description = "مرّر على الشاشة. اتجاهات جاهزة: up/down/left/right، أو حدّد إحداثيات.",
            parameters = mapOf(
                "direction" to ParamSpec(
                    "string", "اتجاه التمرير", listOf("up", "down", "left", "right")
                )
            )
        ),
        ToolSpec(
            name = "press_key",
            description = "اضغط زر نظام: back / home / recents / notifications / enter.",
            parameters = mapOf(
                "key" to ParamSpec(
                    "string", "الزر",
                    listOf("back", "home", "recents", "notifications", "enter")
                )
            ),
            required = listOf("key")
        ),
        ToolSpec(
            name = "open_app",
            description = "افتح تطبيقاً بالاسم الظاهر (مثل «واتساب» أو «YouTube») أو باسم الحزمة (مثل com.whatsapp).",
            parameters = mapOf(
                "app" to ParamSpec("string", "اسم التطبيق أو اسم حزمته")
            ),
            required = listOf("app")
        ),
        ToolSpec(
            name = "list_apps",
            description = "اعرض التطبيقات المثبتة (الاسم + الحزمة).",
            parameters = emptyMap()
        ),
        ToolSpec(
            name = "run_shell",
            description = "نفّذ أمر shell بصلاحيات الروت للمهام المتقدمة. يعمل فقط إن كان الهاتف مروّتاً؛ وإلا استخدم الأدوات الأخرى.",
            parameters = mapOf(
                "command" to ParamSpec("string", "أمر الـ shell")
            ),
            required = listOf("command")
        ),
        ToolSpec(
            name = "wait",
            description = "انتظر مدة قصيرة (مثلاً بعد فتح تطبيق) حتى تستقر الشاشة.",
            parameters = mapOf(
                "ms" to ParamSpec("integer", "مدة الانتظار بالملّي ثانية (افتراضي 800)")
            )
        ),
        ToolSpec(
            name = "finish",
            description = "أنهِ المهمة عند اكتمالها وأبلغ المستخدم بالنتيجة.",
            parameters = mapOf(
                "summary" to ParamSpec("string", "خلاصة ما تم إنجازه للمستخدم")
            ),
            required = listOf("summary")
        )
    )

    /** ينفّذ أداة ويعيد ناتجاً نصياً يُعاد للنموذج. */
    suspend fun execute(name: String, argsJson: String): ToolOutcome {
        val args = runCatching {
            json.parseToJsonElement(argsJson.ifEmpty { "{}" }).jsonObject
        }.getOrDefault(JsonObject(emptyMap()))

        fun intArg(k: String): Int? = args[k]?.jsonPrimitive?.intOrNull
        fun strArg(k: String): String? = args[k]?.jsonPrimitive?.contentOrNull

        val acc = JarvisAccessibilityService.instance

        return when (name) {
            "read_screen" -> {
                val snap = acc?.describeScreen()
                    ?: return ToolOutcome.text("خدمة الوصول غير مفعّلة. فعّلها من الإعدادات.")
                lastSnapshot = snap
                ToolOutcome.text(snap.toPrompt())
            }

            "tap" -> {
                val idx = intArg("index")
                if (idx != null) {
                    val el = lastSnapshot?.elements?.getOrNull(idx)
                        ?: return ToolOutcome.text("لا يوجد عنصر بالفهرس $idx. اقرأ الشاشة أولاً.")
                    val ok = acc?.tap(el.centerX, el.centerY)
                        ?: RootShell.tap(el.centerX, el.centerY).success
                    ToolOutcome.text(if (ok) "تم النقر على \"${el.text}\"" else "فشل النقر")
                } else {
                    val x = intArg("x"); val y = intArg("y")
                    if (x == null || y == null)
                        return ToolOutcome.text("حدّد index أو (x,y).")
                    val ok = acc?.tap(x, y) ?: RootShell.tap(x, y).success
                    ToolOutcome.text(if (ok) "تم النقر على ($x,$y)" else "فشل النقر")
                }
            }

            "type_text" -> {
                val text = strArg("text") ?: return ToolOutcome.text("نص مفقود.")
                val idx = intArg("index")
                val ok = acc?.typeText(text, idx) ?: RootShell.inputText(text).success
                ToolOutcome.text(if (ok) "تمت كتابة النص." else "فشلت الكتابة.")
            }

            "swipe" -> {
                val dir = strArg("direction") ?: "up"
                val (x1, y1, x2, y2) = swipeCoords(dir)
                val ok = acc?.swipe(x1, y1, x2, y2) ?: RootShell.swipe(x1, y1, x2, y2).success
                ToolOutcome.text(if (ok) "تم التمرير $dir" else "فشل التمرير")
            }

            "press_key" -> {
                val key = strArg("key") ?: return ToolOutcome.text("زر مفقود.")
                val ok = when (key) {
                    "back" -> acc?.pressBack() ?: RootShell.keyEvent(4).success
                    "home" -> acc?.pressHome() ?: RootShell.keyEvent(3).success
                    "recents" -> acc?.openRecents() ?: RootShell.keyEvent(187).success
                    "notifications" -> acc?.openNotifications() ?: false
                    "enter" -> acc?.pressEnter() ?: RootShell.keyEvent(66).success
                    else -> false
                }
                ToolOutcome.text(if (ok) "تم الضغط على $key" else "فشل الضغط على $key")
            }

            "open_app" -> {
                val q = strArg("app") ?: strArg("package")
                    ?: return ToolOutcome.text("اسم التطبيق مفقود.")
                val launcherCtx = acc ?: context
                val msg = apps.launch(launcherCtx, q)
                delay(1200)
                ToolOutcome.text(msg)
            }

            "list_apps" -> {
                ToolOutcome.text("التطبيقات المثبتة:\n" +
                    apps.list().joinToString("\n") { "${it.label} — ${it.pkg}" })
            }

            "run_shell" -> {
                val cmd = strArg("command") ?: return ToolOutcome.text("الأمر مفقود.")
                if (!RootShell.isAvailable())
                    return ToolOutcome.text("الهاتف غير مروّت، لذلك run_shell غير متاح. أنجز المهمة بالأدوات الأخرى (open_app، tap، type_text، swipe…).")
                if (isDangerous(cmd))
                    return ToolOutcome.text("رُفض الأمر: قد يتلف النظام أو يمسح البيانات نهائياً. اطلب من المستخدم تنفيذه يدوياً إن كان مقصوداً.")
                ToolOutcome.text(RootShell.exec(cmd).asText())
            }

            "wait" -> {
                delay((intArg("ms") ?: 800).toLong().coerceIn(0, 5000))
                ToolOutcome.text("انتهى الانتظار.")
            }

            "finish" -> ToolOutcome.finish(strArg("summary") ?: "اكتملت المهمة.")

            else -> ToolOutcome.text("أداة غير معروفة: $name")
        }
    }

    private var lastSnapshot: ScreenSnapshot? = null

    private fun swipeCoords(dir: String): List<Int> {
        // نسب من أبعاد الشاشة الفعلية
        val dm = android.content.res.Resources.getSystem().displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        val cx = w / 2; val cy = h / 2
        return when (dir) {
            "up" -> listOf(cx, (h * 0.70).toInt(), cx, (h * 0.30).toInt())
            "down" -> listOf(cx, (h * 0.30).toInt(), cx, (h * 0.70).toInt())
            "left" -> listOf((w * 0.80).toInt(), cy, (w * 0.20).toInt(), cy)
            "right" -> listOf((w * 0.20).toInt(), cy, (w * 0.80).toInt(), cy)
            else -> listOf(cx, (h * 0.70).toInt(), cx, (h * 0.30).toInt())
        }
    }

    /** حماية أساسية من الأوامر المدمّرة التي لا يمكن التراجع عنها. */
    private fun isDangerous(cmd: String): Boolean {
        val c = cmd.lowercase().replace(Regex("\\s+"), " ")
        val patterns = listOf(
            "rm -rf /", "rm -rf /*", "rm -rf /system", "rm -rf /data", "rm -rf /sdcard",
            "mkfs", "dd if=", "of=/dev/block", "format ", "wipe ", "reboot bootloader",
            "> /dev/block", "flash_image"
        )
        return patterns.any { c.contains(it) }
    }
}

/** ناتج تنفيذ أداة. */
data class ToolOutcome(
    val result: String,
    val isFinish: Boolean = false
) {
    companion object {
        fun text(s: String) = ToolOutcome(s, false)
        fun finish(s: String) = ToolOutcome(s, true)
    }
}

private operator fun <T> List<T>.component4(): T = this[3]
