package com.jarvis.agent.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * خدمة الوصول: عينا الوكيل ويداه.
 * - تقرأ شجرة عناصر الشاشة (نصوص، أزرار، مواضع).
 * - تنفّذ إيماءات: نقر، تمرير، كتابة.
 * يصل إليها بقية التطبيق عبر instance الساكن.
 */
class JarvisAccessibilityService : AccessibilityService() {

    private var overlay: AgentOverlay? = null

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        overlay = AgentOverlay(this)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        overlay?.dispose()
        overlay = null
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        overlay?.dispose()
        overlay = null
        instance = null
        super.onDestroy()
    }

    // لا نحتاج الاستماع المستمر للأحداث؛ نقرأ الشجرة عند الطلب.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** اسم حزمة التطبيق الظاهر حالياً في المقدمة. */
    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    /**
     * لقطة نصية لعناصر الشاشة القابلة للتفاعل، مرقّمة ليختار النموذج بينها.
     */
    fun describeScreen(): ScreenSnapshot {
        val root = rootInActiveWindow ?: return ScreenSnapshot(null, emptyList())
        val elements = mutableListOf<UiElement>()
        collect(root, elements)
        return ScreenSnapshot(root.packageName?.toString(), elements)
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<UiElement>, depth: Int = 0) {
        if (node == null || depth > 60) return
        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()
        val label = (text ?: desc)?.trim()
        val usable = node.isClickable || node.isEditable || node.isCheckable ||
            (!label.isNullOrBlank() && node.isVisibleToUser)
        if (usable && node.isVisibleToUser) {
            val b = Rect().also { node.getBoundsInScreen(it) }
            if (b.width() > 0 && b.height() > 0) {
                out.add(
                    UiElement(
                        index = out.size,
                        text = label ?: "",
                        className = node.className?.toString()?.substringAfterLast('.') ?: "",
                        clickable = node.isClickable,
                        editable = node.isEditable,
                        centerX = b.centerX(),
                        centerY = b.centerY(),
                        bounds = b
                    )
                )
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
    }

    /** نقر على إحداثيات عبر إيماءة. */
    suspend fun tap(x: Int, y: Int): Boolean {
        withContext(Dispatchers.Main.immediate) { overlay?.gesture(x, y) }
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        return dispatch(gesture)
    }

    /** تمرير من نقطة إلى نقطة. */
    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, duration: Long = 300): Boolean {
        withContext(Dispatchers.Main.immediate) { overlay?.gesture(x1, y1, x2, y2, duration) }
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        return dispatch(gesture)
    }

    /** كتابة نص في أول حقل قابل للتحرير مُركّز، أو في عنصر بفهرس محدد. */
    fun typeText(text: String, elementIndex: Int? = null): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = if (elementIndex != null) {
            val list = mutableListOf<UiElement>()
            collect(root, list)
            val el = list.getOrNull(elementIndex) ?: return false
            findEditableAt(root, el.centerX, el.centerY)
        } else {
            findFocusedEditable(root)
        } ?: return false

        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
            )
        }
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        // Search the WHOLE tree for the focused field before falling back to
        // the first available one; otherwise a sibling field steals input.
        return findActuallyFocusedEditable(node) ?: firstEditable(node)
    }

    private fun findActuallyFocusedEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) {
            findActuallyFocusedEditable(node.getChild(i))?.let { return it }
        }
        return null
    }

    private fun firstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            firstEditable(node.getChild(i))?.let { return it }
        }
        return null
    }

    private fun findEditableAt(node: AccessibilityNodeInfo?, x: Int, y: Int): AccessibilityNodeInfo? {
        if (node == null) return null
        val b = Rect().also { node.getBoundsInScreen(it) }
        if (node.isEditable && b.contains(x, y)) return node
        for (i in 0 until node.childCount) {
            findEditableAt(node.getChild(i), x, y)?.let { return it }
        }
        return null
    }

    /** زر Enter/إرسال في لوحة المفاتيح عبر الحقل المُركّز (أندرويد 11+). */
    fun pressEnter(): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            return focused.performAction(
                AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id
            )
        }
        return false
    }

    /** أزرار النظام العامة. */
    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    private suspend fun dispatch(gesture: GestureDescription): Boolean {
        val result = CompletableDeferred<Boolean>()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { result.complete(true) }
            override fun onCancelled(d: GestureDescription?) { result.complete(false) }
        }, null)
        if (!ok) return false
        return result.await()
    }
}

/** عنصر واجهة واحد مرئي على الشاشة. */
data class UiElement(
    val index: Int,
    val text: String,
    val className: String,
    val clickable: Boolean,
    val editable: Boolean,
    val centerX: Int,
    val centerY: Int,
    val bounds: Rect
)

/** لقطة كاملة لحالة الشاشة. */
data class ScreenSnapshot(
    val packageName: String?,
    val elements: List<UiElement>
) {
    /** تحويلها إلى نص يفهمه النموذج. */
    fun toPrompt(): String {
        if (elements.isEmpty()) return "الشاشة فارغة أو لا يمكن قراءتها. التطبيق: ${packageName ?: "غير معروف"}"
        val sb = StringBuilder("التطبيق الحالي: ${packageName ?: "غير معروف"}\nعناصر الشاشة:\n")
        elements.take(80).forEach { e ->
            val kind = when {
                e.editable -> "حقل كتابة"
                e.clickable -> "زر/قابل للنقر"
                else -> "نص"
            }
            sb.append("[${e.index}] $kind: \"${e.text}\" @(${e.centerX},${e.centerY})\n")
        }
        return sb.toString()
    }
}
